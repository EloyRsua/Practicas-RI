package uo.ri.cws.application.service.util.dbfixture.records;

import java.sql.Date;
import java.sql.Timestamp;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TInvoicesRecord {
    public String id;
    public Double amount;
    public Timestamp createdAt;
    public Date date;
    public String entityState;
    public Long number;
    public String state;
    public Timestamp updatedAt;
    public Double vat;
    public Long version;
}
