package uo.ri.cws.application.service.util.dbfixture.records;

import java.sql.Timestamp;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TSubstitutionsRecord {
    public String id;
    public Timestamp createdAt;
    public String entityState;
    public Double price;
    public Integer quantity;
    public Timestamp updatedAt;
    public Long version;
    public String intervention_Id;
    public String sparePart_Id;
}
