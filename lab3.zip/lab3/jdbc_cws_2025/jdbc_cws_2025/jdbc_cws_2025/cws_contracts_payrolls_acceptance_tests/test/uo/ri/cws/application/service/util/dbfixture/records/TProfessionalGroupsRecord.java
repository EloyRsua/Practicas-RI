package uo.ri.cws.application.service.util.dbfixture.records;

import java.sql.Timestamp;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TProfessionalGroupsRecord {
    public String id;
    public Timestamp createdAt;
    public String entityState;
    public String name;
    public Double productivityRate;
    public Double trienniumPayment;
    public Timestamp updatedAt;
    public Long version;
}
