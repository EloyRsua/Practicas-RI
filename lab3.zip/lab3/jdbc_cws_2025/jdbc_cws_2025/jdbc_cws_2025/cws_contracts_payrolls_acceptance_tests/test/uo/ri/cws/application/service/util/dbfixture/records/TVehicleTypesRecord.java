package uo.ri.cws.application.service.util.dbfixture.records;

import java.sql.Timestamp;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TVehicleTypesRecord {
    public String id;
    public Timestamp createdAt;
    public String entityState;
    public String name;
    public Double pricePerHour;
    public Timestamp updatedAt;
    public Long version;
}
