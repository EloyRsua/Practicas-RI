package uo.ri.cws.application.service.util.dbfixture.records;

import java.sql.Timestamp;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TVehiclesRecord {
    public String id;
    public Timestamp createdAt;
    public String entityState;
    public String make;
    public String model;
    public String plateNumber;
    public Timestamp updatedAt;
    public Long version;
    public String client_Id;
    public String vehicleType_Id;
}
