package uo.ri.cws.application.service.util.dbfixture.records;

import java.sql.Timestamp;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TMechanicsRecord {
    public String id;
    public Timestamp createdAt;
    public String entityState;
    public String name;
    public String nif;
    public String surname;
    public Timestamp updatedAt;
    public long version;
}
