package uo.ri.cws.application.service.util.dbfixture.records;

import java.sql.Timestamp;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TChargesRecord {
    public String id;
    public Double amount;
    public Timestamp createdAt;
    public String entityState;
    public Timestamp updatedAt;
    public Long version;
    public String invoice_Id;
    public String paymentMean_Id;
}
