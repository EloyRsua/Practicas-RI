package uo.ri.cws.application.service.util.dbfixture.records;

import java.sql.Timestamp;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TInterventionsRecord {
    public String id;
    public Timestamp createdAt;
    public Timestamp updatedAt;
    public String entityState;
    public long version;

    public Timestamp date;
    public int minutes;
    public String mechanic_Id;
    public String workOrder_Id;
}
