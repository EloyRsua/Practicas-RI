package uo.ri.cws.application.service.util.dbfixture.records;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TVouchersRecord {
    public String id;
    public Double available;
    public String code;
    public String description;
}
