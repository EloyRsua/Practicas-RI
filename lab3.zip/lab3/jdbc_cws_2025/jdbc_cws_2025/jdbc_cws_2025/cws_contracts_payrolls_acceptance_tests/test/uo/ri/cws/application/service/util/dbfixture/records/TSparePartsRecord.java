package uo.ri.cws.application.service.util.dbfixture.records;

import java.sql.Timestamp;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TSparePartsRecord {
    public String id;
    public String code;
    public Timestamp createdAt;
    public String description;
    public String entityState;
    public Integer maxStock;
    public Integer minStock;
    public Double price;
    public Integer stock;
    public Timestamp updatedAt;
    public Long version;
}
