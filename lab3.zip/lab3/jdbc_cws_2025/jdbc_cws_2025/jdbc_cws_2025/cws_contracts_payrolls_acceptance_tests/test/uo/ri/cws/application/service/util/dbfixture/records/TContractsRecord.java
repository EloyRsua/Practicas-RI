package uo.ri.cws.application.service.util.dbfixture.records;

import java.sql.Date;
import java.sql.Timestamp;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TContractsRecord {
    public String id;
    public double annualBaseSalary;
    public Timestamp createdAt;
    public Date endDate;
    public String entityState;
    public double settlement;
    public Date startDate;
    public String state;
    public double taxRate;
    public Timestamp updatedAt;
    public long version;
    public String contractType_Id;
    public String mechanic_Id;
    public String professionalGroup_Id;
}
