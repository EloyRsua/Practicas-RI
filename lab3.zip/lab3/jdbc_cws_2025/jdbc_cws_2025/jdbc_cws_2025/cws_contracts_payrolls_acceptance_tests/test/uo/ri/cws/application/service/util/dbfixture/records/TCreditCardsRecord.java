package uo.ri.cws.application.service.util.dbfixture.records;

import java.sql.Date;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TCreditCardsRecord {
    public String id;
    public String number;
    public String type;
    public Date validThru;
}
