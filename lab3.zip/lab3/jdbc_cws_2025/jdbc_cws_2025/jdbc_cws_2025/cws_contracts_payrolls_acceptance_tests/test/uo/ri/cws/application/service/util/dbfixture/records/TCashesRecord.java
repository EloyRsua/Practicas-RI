package uo.ri.cws.application.service.util.dbfixture.records;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TCashesRecord {
    public String id;
}
