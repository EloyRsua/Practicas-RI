package uo.ri.cws.application.service.util.dbfixture.records;

import java.sql.Timestamp;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TWorkOrdersRecord {
    public String id;
    public long version;
    public Timestamp createdAt;
    public Timestamp updatedAt;
    public String entityState;

    public Timestamp date;
    public String description;
    public double amount;
    public String state;

    public String invoice_Id;
    public String mechanic_Id;
    public String vehicle_Id;
}
