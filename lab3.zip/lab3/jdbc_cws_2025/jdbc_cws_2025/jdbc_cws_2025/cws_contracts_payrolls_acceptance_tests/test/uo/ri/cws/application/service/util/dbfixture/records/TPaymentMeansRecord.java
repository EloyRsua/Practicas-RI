package uo.ri.cws.application.service.util.dbfixture.records;

import java.sql.Timestamp;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TPaymentMeansRecord {
    public String id;
    public String dtype;
    public Double accumulated;
    public Timestamp createdAt;
    public String entityState;
    public Timestamp updatedAt;
    public Long version;
    public String client_Id;
}
