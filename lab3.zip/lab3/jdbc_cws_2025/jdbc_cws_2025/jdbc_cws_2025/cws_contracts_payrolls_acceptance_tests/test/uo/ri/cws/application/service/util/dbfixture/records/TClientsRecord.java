package uo.ri.cws.application.service.util.dbfixture.records;

import java.sql.Timestamp;

import javax.annotation.processing.Generated;

@Generated("LLM")
public class TClientsRecord {
    public String id;
    public Timestamp createdAt;
    public String email;
    public String entityState;
    public String name;
    public String nif;
    public String phone;
    public String surname;
    public Timestamp updatedAt;
    public Long version;
    public String city;
    public String street;
    public String zipCode;
}
