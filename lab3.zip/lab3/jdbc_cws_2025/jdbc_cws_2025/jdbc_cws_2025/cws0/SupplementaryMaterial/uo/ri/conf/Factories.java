package uo.ri.conf;

import uo.ri.cws.application.service.ServiceFactory;

public class Factories {

    public static ServiceFactory service = new ServiceFactory();

    public static void close() {
    }

}