package uo.ri.cws.application.ui.manager.contracts.professionalgroup.action;

import uo.ri.util.menu.Action;

public class ListAllProfessionalGroupsAction implements Action {

    @Override
    public void execute() throws Exception {
        throw new UnsupportedOperationException("Not yet implemented");

//        if (groups.isEmpty()) {
//            Console.println("No professional groups found");
//            return;
//        }
//        
//        for (ProfessionalGroupDto dto : groups) {
//            Printer.printProfessionalGroup(dto);
//        }
    }
}