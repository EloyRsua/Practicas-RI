package uo.ri.cws.application.ui.manager.payroll.action;

import uo.ri.util.console.Console;
import uo.ri.util.exception.BusinessException;
import uo.ri.util.menu.Action;

public class ListPayrollsOfMechanicAction implements Action {

    @Override
    public void execute() throws BusinessException {
        String mechanicId = Console.readString("Mechanic id");

        throw new UnsupportedOperationException("Not yet implemented");

//        if (payrolls.isEmpty()) {
//            Console.println("No payrolls found for this mechanic");
//            return;
//        }
//        
//        for (PayrollSummaryDto dto : payrolls) {
//            Printer.printPayrollSummary(dto);
//        }
    }
}