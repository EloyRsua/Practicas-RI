package uo.ri.cws.application.ui.manager.contracts.contracttype.action;

import uo.ri.util.menu.Action;

public class ListAllContractTypesAction implements Action {

    @Override
    public void execute() throws Exception {

        throw new UnsupportedOperationException("Not yet implemented");

//		if (types.isEmpty()) {
//			Console.println("No contract types found");
//			return;
//		}
//		
//		for (ContractTypeDto dto : types) {
//			Printer.printContractType(dto);
//		}
    }

}