package uo.ri.cws.application.ui.manager.payroll.action;

import uo.ri.util.console.Console;
import uo.ri.util.exception.BusinessException;
import uo.ri.util.menu.Action;

public class ListPayrollsOfProfGroupAction implements Action {

    @Override
    public void execute() throws BusinessException {
        String groupName = Console.readString("Professional group name");

        throw new UnsupportedOperationException("Not yet implemented");

//        if (payrolls.isEmpty()) {
//            Console.println("No payrolls found for this professional group");
//            return;
//        }
//        
//        for (PayrollSummaryDto dto : payrolls) {
//            Printer.printPayrollSummary(dto);
//        }
    }
}