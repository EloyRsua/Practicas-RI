package uo.ri.cws.application.ui.manager.payroll.action;

import uo.ri.util.exception.BusinessException;
import uo.ri.util.menu.Action;

public class DeleteLastMonthPayrollAction implements Action {

    @Override
    public void execute() throws BusinessException {
        throw new UnsupportedOperationException("Not yet implemented");

//        Console.println("Last month's payrolls deleted");
    }
}