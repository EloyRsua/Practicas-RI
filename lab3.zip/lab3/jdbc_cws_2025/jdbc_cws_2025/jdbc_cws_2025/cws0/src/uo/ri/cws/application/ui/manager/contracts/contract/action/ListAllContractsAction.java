package uo.ri.cws.application.ui.manager.contracts.contract.action;

import uo.ri.util.menu.Action;

public class ListAllContractsAction implements Action {

    @Override
    public void execute() throws Exception {
        throw new UnsupportedOperationException("Not yet implemented");
        /*
         * if (contracts.isEmpty()) { Console.println("No contracts found");
         * return; }
         * 
         * for (ContractSummaryDto c : contracts) {
         * Printer.printContractSummary(c); }
         */
    }

}